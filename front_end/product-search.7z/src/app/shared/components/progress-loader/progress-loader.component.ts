import { CommonModule } from '@angular/common';
import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-progress-loader',
  imports: [CommonModule],
  templateUrl: './progress-loader.component.html',
  styleUrl: './progress-loader.component.css'
})
export class ProgressLoaderComponent {

  @Input() loading = false;
  progress = 0;
  private progressInterval: any;
  private startTime: number = 0;

  ngOnInit() {
    this.resetProgress();
  }

  ngOnChanges() {
    if (this.loading) {
      this.startProgress();
    } else {
      this.completeProgress();
    }
  }

  private startProgress() {
    this.resetProgress();
    this.startTime = Date.now();
    
    this.progressInterval = setInterval(() => {
      const elapsedTime = Date.now() - this.startTime;
      
      if (this.progress < 97) {
        if (elapsedTime < 25000) {
          this.progress += 0.8;
        } else if (elapsedTime < 40000) {
          this.progress += 0.4;
        } else if (elapsedTime < 50000) {
          this.progress += 0.25;
        } else if (elapsedTime < 55000) {
          this.progress += 0.15;
        } else if (elapsedTime < 60000) {
          this.progress += 0.1;
        } else {
          this.progress += 0.05;
        }
      }
      
      this.progress = Math.min(97, this.progress);
    }, 100);
  }

  private completeProgress() {
    clearInterval(this.progressInterval);
    this.progress = 100;
    
    // Reset after showing 100%
    setTimeout(() => {
      this.resetProgress();
    }, 500);
  }

  private resetProgress() {
    clearInterval(this.progressInterval);
    this.progress = 0;
  }

  ngOnDestroy() {
    clearInterval(this.progressInterval);
  }

}
